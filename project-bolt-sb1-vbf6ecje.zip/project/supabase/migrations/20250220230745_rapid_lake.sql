/*
  # Add source tracking columns to customer_tiers

  1. Changes
    - Add source_type and source_id columns to customer_tiers table
    - Set default values for existing rows
    - Add NOT NULL constraints
    - Add index for better query performance

  2. Security
    - Maintains existing RLS policies
*/

-- First, ensure any NULL values are updated to a default value
UPDATE customer_tiers 
SET 
  source_type = 'manual',
  source_id = customer_id
WHERE 
  source_type IS NULL 
  OR source_id IS NULL;

-- Add NOT NULL constraints
ALTER TABLE customer_tiers
  ALTER COLUMN source_type SET NOT NULL,
  ALTER COLUMN source_id SET NOT NULL;

-- Add index for source columns if it doesn't exist
CREATE INDEX IF NOT EXISTS idx_customer_tiers_source 
  ON customer_tiers(source_type, source_id);