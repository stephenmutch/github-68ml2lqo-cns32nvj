/*
  # Create Allocation Wizard Schema

  1. New Tables
    - Updated `allocations` table with wizard fields
    - Updated `allocation_products` table with product configuration fields

  2. Changes
    - Added new columns to support allocation wizard configuration
    - Added constraints and default values
    - Updated RLS policies

  3. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Update allocations table with wizard fields
ALTER TABLE allocations
ADD COLUMN IF NOT EXISTS allocation_type text NOT NULL DEFAULT 'individual',
ADD COLUMN IF NOT EXISTS title text,
ADD COLUMN IF NOT EXISTS message text,
ADD COLUMN IF NOT EXISTS confirmation_message text,
ADD COLUMN IF NOT EXISTS cart_min integer,
ADD COLUMN IF NOT EXISTS cart_max integer,
ADD COLUMN IF NOT EXISTS min_amount numeric(12,2),
ADD COLUMN IF NOT EXISTS order_discount_type text CHECK (order_discount_type IN ('percentage', 'fixed')),
ADD COLUMN IF NOT EXISTS order_discount_amount numeric(12,2),
ADD COLUMN IF NOT EXISTS shipping_discount_type text CHECK (shipping_discount_type IN ('percentage', 'fixed')),
ADD COLUMN IF NOT EXISTS shipping_discount_amount numeric(12,2),
ADD COLUMN IF NOT EXISTS shipping_discount_method text;

-- Update allocation_products table with configuration fields
ALTER TABLE allocation_products
ADD COLUMN IF NOT EXISTS override_price numeric(12,2),
ADD COLUMN IF NOT EXISTS min_purchase integer,
ADD COLUMN IF NOT EXISTS max_purchase integer,
ADD COLUMN IF NOT EXISTS allow_wish_requests boolean NOT NULL DEFAULT false,
ADD COLUMN IF NOT EXISTS wish_request_min integer,
ADD COLUMN IF NOT EXISTS wish_request_max integer;

-- Add check constraints
ALTER TABLE allocations
ADD CONSTRAINT cart_min_non_negative CHECK (cart_min >= 0),
ADD CONSTRAINT cart_max_non_negative CHECK (cart_max >= 0),
ADD CONSTRAINT min_amount_non_negative CHECK (min_amount >= 0),
ADD CONSTRAINT cart_max_greater_than_min CHECK (cart_max >= cart_min),
ADD CONSTRAINT discount_amounts_non_negative CHECK (
  (order_discount_amount IS NULL OR order_discount_amount >= 0) AND
  (shipping_discount_amount IS NULL OR shipping_discount_amount >= 0)
);

ALTER TABLE allocation_products
ADD CONSTRAINT override_price_non_negative CHECK (override_price >= 0),
ADD CONSTRAINT min_purchase_non_negative CHECK (min_purchase >= 0),
ADD CONSTRAINT max_purchase_non_negative CHECK (max_purchase >= 0),
ADD CONSTRAINT max_purchase_greater_than_min CHECK (max_purchase >= min_purchase),
ADD CONSTRAINT wish_request_min_non_negative CHECK (wish_request_min >= 0),
ADD CONSTRAINT wish_request_max_non_negative CHECK (wish_request_max >= 0),
ADD CONSTRAINT wish_request_max_greater_than_min CHECK (wish_request_max >= wish_request_min);

-- Update RLS policies
CREATE POLICY "Users can read allocations"
  ON allocations
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert allocations"
  ON allocations
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Users can update allocations"
  ON allocations
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Users can read allocation products"
  ON allocation_products
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert allocation products"
  ON allocation_products
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Users can update allocation products"
  ON allocation_products
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);