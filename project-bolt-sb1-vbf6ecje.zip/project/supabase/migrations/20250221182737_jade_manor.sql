-- Update existing status values to match new types
UPDATE allocations
SET status = CASE
  WHEN status = 'active' THEN 'open'
  WHEN status = 'scheduled' THEN 'upcoming'
  WHEN status = 'completed' THEN 'previous'
  ELSE 'upcoming' -- Default for any other values
END;

-- Add check constraint for status values
ALTER TABLE allocations
  ADD CONSTRAINT allocations_status_check
  CHECK (status IN ('open', 'upcoming', 'previous'));

-- Add comment explaining status values
COMMENT ON COLUMN allocations.status IS 'Status of the allocation: open (currently active), upcoming (scheduled), or previous (completed)';Lets Le