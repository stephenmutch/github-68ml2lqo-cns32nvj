/*
  # Fix customer tiers source tracking

  1. Changes
    - Add NOT NULL constraints to source_type and source_id columns
    - Add indexes for better performance
    - Update existing rows with default values

  2. Security
    - Maintain existing RLS policies
*/

-- First, ensure any NULL values are updated to a default value
UPDATE customer_tiers 
SET 
  source_type = 'manual',
  source_id = customer_id
WHERE 
  source_type IS NULL 
  OR source_id IS NULL;

-- Add NOT NULL constraints
ALTER TABLE customer_tiers
  ALTER COLUMN source_type SET NOT NULL,
  ALTER COLUMN source_id SET NOT NULL;

-- Add index for source columns if it doesn't exist
CREATE INDEX IF NOT EXISTS idx_customer_tiers_source 
  ON customer_tiers(source_type, source_id);