/*
  # Add tier overrides table

  1. New Tables
    - `tier_overrides`
      - `id` (uuid, primary key)
      - `tier_id` (uuid, references allocation_tiers)
      - `requirements` (jsonb)
      - `discounts` (jsonb)
      - `shipping` (jsonb)
      - `has_product_overrides` (boolean)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `tier_overrides` table
    - Add policy for authenticated users
*/

CREATE TABLE IF NOT EXISTS tier_overrides (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tier_id uuid REFERENCES allocation_tiers(id) ON DELETE CASCADE,
  requirements jsonb,
  discounts jsonb,
  shipping jsonb,
  has_product_overrides boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE tier_overrides ENABLE ROW LEVEL SECURITY;

-- Create policy for authenticated users
CREATE POLICY "Enable full access to authenticated users"
  ON tier_overrides
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Add source tracking columns to customer_tiers
ALTER TABLE customer_tiers 
ADD COLUMN IF NOT EXISTS source_type text,
ADD COLUMN IF NOT EXISTS source_id text;