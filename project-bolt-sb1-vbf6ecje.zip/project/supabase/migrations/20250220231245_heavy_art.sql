/*
  # Add source tracking columns to customer_tiers

  1. Changes
    - Add source_type and source_id columns to customer_tiers table
    - Set default values for existing rows
    - Add NOT NULL constraints
    - Add check constraint for source_type values
    - Add index for better query performance
    - Add helpful column comments

  2. Security
    - Maintains existing RLS policies
*/

-- Add columns if they don't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'customer_tiers' AND column_name = 'source_type'
  ) THEN
    ALTER TABLE customer_tiers ADD COLUMN source_type text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'customer_tiers' AND column_name = 'source_id'
  ) THEN
    ALTER TABLE customer_tiers ADD COLUMN source_id text;
  END IF;
END $$;

-- Set default values for any existing NULL values
UPDATE customer_tiers 
SET 
  source_type = COALESCE(source_type, 'manual'),
  source_id = COALESCE(source_id, customer_id)
WHERE 
  source_type IS NULL 
  OR source_id IS NULL;

-- Add NOT NULL constraints
ALTER TABLE customer_tiers
  ALTER COLUMN source_type SET NOT NULL,
  ALTER COLUMN source_id SET NOT NULL;

-- Add check constraint to validate source_type values
ALTER TABLE customer_tiers
  ADD CONSTRAINT customer_tiers_source_type_check
  CHECK (source_type IN ('manual', 'query', 'tag', 'group', 'club', 'search'));

-- Add index for better query performance
CREATE INDEX IF NOT EXISTS idx_customer_tiers_source 
  ON customer_tiers(source_type, source_id);

-- Add helpful column comments
COMMENT ON COLUMN customer_tiers.source_type IS 'Type of source that added the customer (manual, query, tag, group, club, search)';
COMMENT ON COLUMN customer_tiers.source_id IS 'ID of the source that added the customer';