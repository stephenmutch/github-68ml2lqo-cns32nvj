/*
  # Fix tier tables and migrations

  1. Changes
    - Drop duplicate policies
    - Ensure tier_overrides table exists with proper structure
    - Add source tracking columns to customer_tiers
    - Add proper constraints and indexes
    - Clean up redundant migrations

  2. Security
    - Maintain RLS policies
    - Ensure proper cascade behavior
*/

-- First, clean up any duplicate policies
DO $$ 
BEGIN
  -- Drop all existing policies for tier_overrides
  DROP POLICY IF EXISTS "Enable full access to authenticated users" ON tier_overrides;
  DROP POLICY IF EXISTS "Allow authenticated full access to tier_overrides" ON tier_overrides;
END $$;

-- Recreate tier_overrides table with proper structure
CREATE TABLE IF NOT EXISTS tier_overrides (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tier_id uuid REFERENCES allocation_tiers(id) ON DELETE CASCADE,
  requirements jsonb DEFAULT NULL,
  discounts jsonb DEFAULT NULL,
  shipping jsonb DEFAULT NULL,
  has_product_overrides boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT tier_overrides_tier_id_key UNIQUE (tier_id)
);

-- Add source tracking columns to customer_tiers if they don't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'customer_tiers' AND column_name = 'source_type'
  ) THEN
    ALTER TABLE customer_tiers ADD COLUMN source_type text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'customer_tiers' AND column_name = 'source_id'
  ) THEN
    ALTER TABLE customer_tiers ADD COLUMN source_id text;
  END IF;
END $$;

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_tier_overrides_tier_id ON tier_overrides(tier_id);
CREATE INDEX IF NOT EXISTS idx_customer_tiers_source ON customer_tiers(source_type, source_id);

-- Enable RLS
ALTER TABLE tier_overrides ENABLE ROW LEVEL SECURITY;

-- Create single policy for authenticated users
CREATE POLICY "Enable full access to authenticated users"
  ON tier_overrides
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Add trigger to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_tier_overrides_updated_at
  BEFORE UPDATE ON tier_overrides
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();