/*
  # Fix customer tiers source tracking

  1. Changes
    - Drop and recreate customer_tiers table with proper structure
    - Add source tracking columns with proper constraints
    - Ensure proper cascade behavior
    - Add indexes for performance

  2. Security
    - Maintain RLS policies
    - Add proper constraints
*/

-- Drop existing table and recreate with proper structure
DROP TABLE IF EXISTS customer_tiers CASCADE;

CREATE TABLE customer_tiers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  allocation_id uuid REFERENCES allocations(id) ON DELETE CASCADE NOT NULL,
  customer_id text NOT NULL,
  tier_id uuid REFERENCES allocation_tiers(id) ON DELETE CASCADE,
  pvn_score numeric(5,2),
  has_purchased boolean DEFAULT false,
  last_engagement timestamptz,
  source_type text NOT NULL,
  source_id text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Add indexes for better performance
CREATE INDEX idx_customer_tiers_allocation ON customer_tiers(allocation_id);
CREATE INDEX idx_customer_tiers_tier ON customer_tiers(tier_id);
CREATE INDEX idx_customer_tiers_customer ON customer_tiers(customer_id);
CREATE INDEX idx_customer_tiers_source ON customer_tiers(source_type, source_id);

-- Enable RLS
ALTER TABLE customer_tiers ENABLE ROW LEVEL SECURITY;

-- Create policy for authenticated users
CREATE POLICY "Enable full access to authenticated users"
  ON customer_tiers
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Add trigger for updated_at
CREATE TRIGGER update_customer_tiers_updated_at
  BEFORE UPDATE ON customer_tiers
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();