-- Create tier_product_overrides table
CREATE TABLE IF NOT EXISTS tier_product_overrides (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tier_id uuid REFERENCES allocation_tiers(id) ON DELETE CASCADE,
  product_id text NOT NULL,
  override_price numeric(12,2),
  min_purchase integer,
  max_purchase integer,
  allow_wish_requests boolean DEFAULT false,
  wish_request_min integer,
  wish_request_max integer,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT tier_product_overrides_tier_product_unique UNIQUE (tier_id, product_id)
);

-- Add indexes
CREATE INDEX idx_tier_product_overrides_tier ON tier_product_overrides(tier_id);
CREATE INDEX idx_tier_product_overrides_product ON tier_product_overrides(product_id);

-- Enable RLS
ALTER TABLE tier_product_overrides ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Enable read access for authenticated users"
  ON tier_product_overrides FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Enable insert access for authenticated users"
  ON tier_product_overrides FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Enable update access for authenticated users"
  ON tier_product_overrides FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Enable delete access for authenticated users"
  ON tier_product_overrides FOR DELETE
  TO authenticated
  USING (true);

-- Add trigger for updated_at
CREATE TRIGGER update_tier_product_overrides_updated_at
  BEFORE UPDATE ON tier_product_overrides
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Add helpful comments
COMMENT ON TABLE tier_product_overrides IS 'Stores product-specific overrides for allocation tiers';
COMMENT ON COLUMN tier_product_overrides.override_price IS 'Custom price for this product in this tier';
COMMENT ON COLUMN tier_product_overrides.min_purchase IS 'Minimum purchase quantity for this product in this tier';
COMMENT ON COLUMN tier_product_overrides.max_purchase IS 'Maximum purchase quantity for this product in this tier';
COMMENT ON COLUMN tier_product_overrides.allow_wish_requests IS 'Whether wish requests are allowed for this product in this tier';
COMMENT ON COLUMN tier_product_overrides.wish_request_min IS 'Minimum wish request quantity for this product in this tier';
COMMENT ON COLUMN tier_product_overrides.wish_request_max IS 'Maximum wish request quantity for this product in this tier';