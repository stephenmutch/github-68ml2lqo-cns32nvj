/*
  # Allocation System Database Schema

  1. New Tables
    - `allocations`
      - Core allocation/offering season details
      - Tracks overall allocation status and metrics
    - `allocation_tiers`
      - Tier configuration for each allocation
      - Defines access levels and privileges
    - `allocation_products`
      - Products available in each allocation
      - Tracks inventory and tier-specific limits
    - `customer_tiers`
      - Maps customers to their tiers
      - Stores customer-specific allocation data
    - `allocation_requests`
      - Tracks wishlist/additional requests
      - Manages request status and priority
    - `allocation_metrics`
      - Stores real-time allocation performance data
      - Tracks sales, engagement, and inventory metrics

  2. Security
    - Enable RLS on all tables
    - Policies for authenticated admin access
*/

-- Allocations table
CREATE TABLE IF NOT EXISTS allocations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  status text NOT NULL DEFAULT 'draft',
  start_date timestamptz NOT NULL,
  end_date timestamptz NOT NULL,
  total_customers integer DEFAULT 0,
  current_revenue numeric(12,2) DEFAULT 0,
  expected_revenue numeric(12,2) DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Allocation tiers
CREATE TABLE IF NOT EXISTS allocation_tiers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  allocation_id uuid REFERENCES allocations(id),
  name text NOT NULL,
  level integer NOT NULL,
  access_start timestamptz,
  access_end timestamptz,
  customer_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Allocation products
CREATE TABLE IF NOT EXISTS allocation_products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  allocation_id uuid REFERENCES allocations(id),
  product_id text NOT NULL, -- References external product system
  total_inventory integer NOT NULL,
  remaining_inventory integer NOT NULL,
  tier_restrictions jsonb, -- Tier-specific inventory limits
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Customer tiers
CREATE TABLE IF NOT EXISTS customer_tiers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  allocation_id uuid REFERENCES allocations(id),
  customer_id text NOT NULL, -- References external customer system
  tier_id uuid REFERENCES allocation_tiers(id),
  pvn_score numeric(5,2), -- Predictive Value Number
  has_purchased boolean DEFAULT false,
  last_engagement timestamptz,
  created_at timestamptz DEFAULT now()
);

-- Allocation requests (wishlist)
CREATE TABLE IF NOT EXISTS allocation_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  allocation_id uuid REFERENCES allocations(id),
  customer_id text NOT NULL,
  product_id text NOT NULL,
  quantity integer NOT NULL,
  status text DEFAULT 'pending',
  priority integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Allocation metrics
CREATE TABLE IF NOT EXISTS allocation_metrics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  allocation_id uuid REFERENCES allocations(id),
  metric_date date NOT NULL,
  daily_revenue numeric(12,2) DEFAULT 0,
  daily_orders integer DEFAULT 0,
  daily_customers integer DEFAULT 0,
  inventory_depletion numeric(5,2) DEFAULT 0,
  engagement_rate numeric(5,2) DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE allocations ENABLE ROW LEVEL SECURITY;
ALTER TABLE allocation_tiers ENABLE ROW LEVEL SECURITY;
ALTER TABLE allocation_products ENABLE ROW LEVEL SECURITY;
ALTER TABLE customer_tiers ENABLE ROW LEVEL SECURITY;
ALTER TABLE allocation_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE allocation_metrics ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Allow authenticated full access to allocations"
  ON allocations FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow authenticated full access to allocation_tiers"
  ON allocation_tiers FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow authenticated full access to allocation_products"
  ON allocation_products FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow authenticated full access to customer_tiers"
  ON customer_tiers FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow authenticated full access to allocation_requests"
  ON allocation_requests FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow authenticated full access to allocation_metrics"
  ON allocation_metrics FOR ALL TO authenticated
  USING (true)
  WITH CHECK (true);