/*
  # Update allocation tables with additional fields and policies

  1. Schema Updates
    - Add new fields to allocations table for wizard configuration
    - Add new fields to allocation_products table for product configuration
    - Add check constraints for data validation
  
  2. Security
    - Update RLS policies for better access control
*/

-- Update allocations table with wizard fields
DO $$ 
BEGIN
  -- Add columns if they don't exist
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'allocations' AND column_name = 'allocation_type') THEN
    ALTER TABLE allocations ADD COLUMN allocation_type text NOT NULL DEFAULT 'individual';
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'allocations' AND column_name = 'title') THEN
    ALTER TABLE allocations ADD COLUMN title text;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'allocations' AND column_name = 'message') THEN
    ALTER TABLE allocations ADD COLUMN message text;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'allocations' AND column_name = 'confirmation_message') THEN
    ALTER TABLE allocations ADD COLUMN confirmation_message text;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'allocations' AND column_name = 'cart_min') THEN
    ALTER TABLE allocations ADD COLUMN cart_min integer;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'allocations' AND column_name = 'cart_max') THEN
    ALTER TABLE allocations ADD COLUMN cart_max integer;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'allocations' AND column_name = 'min_amount') THEN
    ALTER TABLE allocations ADD COLUMN min_amount numeric(12,2);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'allocations' AND column_name = 'order_discount_type') THEN
    ALTER TABLE allocations ADD COLUMN order_discount_type text CHECK (order_discount_type IN ('percentage', 'fixed'));
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'allocations' AND column_name = 'order_discount_amount') THEN
    ALTER TABLE allocations ADD COLUMN order_discount_amount numeric(12,2);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'allocations' AND column_name = 'shipping_discount_type') THEN
    ALTER TABLE allocations ADD COLUMN shipping_discount_type text CHECK (shipping_discount_type IN ('percentage', 'fixed'));
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'allocations' AND column_name = 'shipping_discount_amount') THEN
    ALTER TABLE allocations ADD COLUMN shipping_discount_amount numeric(12,2);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'allocations' AND column_name = 'shipping_discount_method') THEN
    ALTER TABLE allocations ADD COLUMN shipping_discount_method text;
  END IF;
END $$;

-- Update allocation_products table with configuration fields
DO $$ 
BEGIN
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'allocation_products' AND column_name = 'override_price') THEN
    ALTER TABLE allocation_products ADD COLUMN override_price numeric(12,2);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'allocation_products' AND column_name = 'min_purchase') THEN
    ALTER TABLE allocation_products ADD COLUMN min_purchase integer;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'allocation_products' AND column_name = 'max_purchase') THEN
    ALTER TABLE allocation_products ADD COLUMN max_purchase integer;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'allocation_products' AND column_name = 'allow_wish_requests') THEN
    ALTER TABLE allocation_products ADD COLUMN allow_wish_requests boolean NOT NULL DEFAULT false;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'allocation_products' AND column_name = 'wish_request_min') THEN
    ALTER TABLE allocation_products ADD COLUMN wish_request_min integer;
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.columns WHERE table_name = 'allocation_products' AND column_name = 'wish_request_max') THEN
    ALTER TABLE allocation_products ADD COLUMN wish_request_max integer;
  END IF;
END $$;

-- Add check constraints if they don't exist
DO $$ 
BEGIN
  -- Allocations table constraints
  IF NOT EXISTS (SELECT 1 FROM information_schema.constraint_column_usage WHERE constraint_name = 'cart_min_non_negative') THEN
    ALTER TABLE allocations ADD CONSTRAINT cart_min_non_negative CHECK (cart_min >= 0);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.constraint_column_usage WHERE constraint_name = 'cart_max_non_negative') THEN
    ALTER TABLE allocations ADD CONSTRAINT cart_max_non_negative CHECK (cart_max >= 0);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.constraint_column_usage WHERE constraint_name = 'min_amount_non_negative') THEN
    ALTER TABLE allocations ADD CONSTRAINT min_amount_non_negative CHECK (min_amount >= 0);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.constraint_column_usage WHERE constraint_name = 'cart_max_greater_than_min') THEN
    ALTER TABLE allocations ADD CONSTRAINT cart_max_greater_than_min CHECK (cart_max >= cart_min);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.constraint_column_usage WHERE constraint_name = 'discount_amounts_non_negative') THEN
    ALTER TABLE allocations ADD CONSTRAINT discount_amounts_non_negative CHECK (
      (order_discount_amount IS NULL OR order_discount_amount >= 0) AND
      (shipping_discount_amount IS NULL OR shipping_discount_amount >= 0)
    );
  END IF;

  -- Allocation products table constraints
  IF NOT EXISTS (SELECT 1 FROM information_schema.constraint_column_usage WHERE constraint_name = 'override_price_non_negative') THEN
    ALTER TABLE allocation_products ADD CONSTRAINT override_price_non_negative CHECK (override_price >= 0);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.constraint_column_usage WHERE constraint_name = 'min_purchase_non_negative') THEN
    ALTER TABLE allocation_products ADD CONSTRAINT min_purchase_non_negative CHECK (min_purchase >= 0);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.constraint_column_usage WHERE constraint_name = 'max_purchase_non_negative') THEN
    ALTER TABLE allocation_products ADD CONSTRAINT max_purchase_non_negative CHECK (max_purchase >= 0);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.constraint_column_usage WHERE constraint_name = 'max_purchase_greater_than_min') THEN
    ALTER TABLE allocation_products ADD CONSTRAINT max_purchase_greater_than_min CHECK (max_purchase >= min_purchase);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.constraint_column_usage WHERE constraint_name = 'wish_request_min_non_negative') THEN
    ALTER TABLE allocation_products ADD CONSTRAINT wish_request_min_non_negative CHECK (wish_request_min >= 0);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.constraint_column_usage WHERE constraint_name = 'wish_request_max_non_negative') THEN
    ALTER TABLE allocation_products ADD CONSTRAINT wish_request_max_non_negative CHECK (wish_request_max >= 0);
  END IF;
  
  IF NOT EXISTS (SELECT 1 FROM information_schema.constraint_column_usage WHERE constraint_name = 'wish_request_max_greater_than_min') THEN
    ALTER TABLE allocation_products ADD CONSTRAINT wish_request_max_greater_than_min CHECK (wish_request_max >= wish_request_min);
  END IF;
END $$;

-- Drop existing policies if they exist
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can read allocations" ON allocations;
  DROP POLICY IF EXISTS "Users can insert allocations" ON allocations;
  DROP POLICY IF EXISTS "Users can update allocations" ON allocations;
  DROP POLICY IF EXISTS "Users can read allocation products" ON allocation_products;
  DROP POLICY IF EXISTS "Users can insert allocation products" ON allocation_products;
  DROP POLICY IF EXISTS "Users can update allocation products" ON allocation_products;
  DROP POLICY IF EXISTS "Allow authenticated full access to allocations" ON allocations;
  DROP POLICY IF EXISTS "Allow authenticated full access to allocation_products" ON allocation_products;
  DROP POLICY IF EXISTS "Enable full access to authenticated users" ON allocations;
  DROP POLICY IF EXISTS "Enable full access to authenticated users" ON allocation_products;
END $$;

-- Create a single policy for full access to allocations
CREATE POLICY "Enable full access to authenticated users"
  ON allocations
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create a single policy for full access to allocation products
CREATE POLICY "Enable full access to authenticated users"
  ON allocation_products
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);