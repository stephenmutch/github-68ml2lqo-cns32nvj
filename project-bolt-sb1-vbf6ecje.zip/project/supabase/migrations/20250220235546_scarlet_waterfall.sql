/*
  # Fix customer tiers schema

  1. Changes
    - Drop and recreate customer_tiers table with correct schema
    - Add proper constraints and indexes
    - Enable RLS and create policies

  2. Security
    - Enable RLS
    - Add policies for authenticated users
*/

-- Drop existing table and recreate with proper structure
DROP TABLE IF EXISTS customer_tiers CASCADE;

CREATE TABLE customer_tiers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  allocation_id uuid REFERENCES allocations(id) ON DELETE CASCADE NOT NULL,
  customer_id text NOT NULL,
  tier_id uuid REFERENCES allocation_tiers(id) ON DELETE CASCADE,
  pvn_score numeric(5,2),
  has_purchased boolean DEFAULT false,
  last_engagement timestamptz,
  source_type text NOT NULL,
  source_id text NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT customer_tiers_source_type_check CHECK (source_type IN ('manual', 'query', 'tag', 'group', 'club', 'search'))
);

-- Add indexes for better performance
CREATE INDEX idx_customer_tiers_allocation ON customer_tiers(allocation_id);
CREATE INDEX idx_customer_tiers_tier ON customer_tiers(tier_id);
CREATE INDEX idx_customer_tiers_customer ON customer_tiers(customer_id);
CREATE INDEX idx_customer_tiers_source ON customer_tiers(source_type, source_id);

-- Enable RLS
ALTER TABLE customer_tiers ENABLE ROW LEVEL SECURITY;

-- Create policies for authenticated users
CREATE POLICY "Enable read access for authenticated users"
  ON customer_tiers FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Enable insert access for authenticated users"
  ON customer_tiers FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Enable update access for authenticated users"
  ON customer_tiers FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Enable delete access for authenticated users"
  ON customer_tiers FOR DELETE
  TO authenticated
  USING (true);

-- Add trigger for updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_customer_tiers_updated_at
  BEFORE UPDATE ON customer_tiers
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Add helpful comments
COMMENT ON TABLE customer_tiers IS 'Stores customer tier assignments for allocations';
COMMENT ON COLUMN customer_tiers.source_type IS 'Type of source that added the customer (manual, query, tag, group, club, search)';
COMMENT ON COLUMN customer_tiers.source_id IS 'ID of the source that added the customer';