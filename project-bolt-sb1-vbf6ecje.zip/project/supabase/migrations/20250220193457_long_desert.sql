/*
  # Fix RLS policies for allocations

  1. Security Updates
    - Ensure RLS is enabled on tables
    - Drop all existing policies
    - Create new comprehensive policies for authenticated users
*/

-- Enable RLS on tables (in case it was disabled)
ALTER TABLE allocations ENABLE ROW LEVEL SECURITY;
ALTER TABLE allocation_products ENABLE ROW LEVEL SECURITY;

-- Drop all existing policies
DO $$ 
BEGIN
  DROP POLICY IF EXISTS "Users can read allocations" ON allocations;
  DROP POLICY IF EXISTS "Users can insert allocations" ON allocations;
  DROP POLICY IF EXISTS "Users can update allocations" ON allocations;
  DROP POLICY IF EXISTS "Users can read allocation products" ON allocation_products;
  DROP POLICY IF EXISTS "Users can insert allocation products" ON allocation_products;
  DROP POLICY IF EXISTS "Users can update allocation products" ON allocation_products;
  DROP POLICY IF EXISTS "Allow authenticated full access to allocations" ON allocations;
  DROP POLICY IF EXISTS "Allow authenticated full access to allocation_products" ON allocation_products;
  DROP POLICY IF EXISTS "Enable full access to authenticated users" ON allocations;
  DROP POLICY IF EXISTS "Enable full access to authenticated users" ON allocation_products;
END $$;

-- Create new policies with explicit permissions for each operation
CREATE POLICY "Allow authenticated users to select allocations"
  ON allocations FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Allow authenticated users to insert allocations"
  ON allocations FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Allow authenticated users to update allocations"
  ON allocations FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow authenticated users to delete allocations"
  ON allocations FOR DELETE
  TO authenticated
  USING (true);

-- Repeat for allocation_products
CREATE POLICY "Allow authenticated users to select allocation_products"
  ON allocation_products FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Allow authenticated users to insert allocation_products"
  ON allocation_products FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Allow authenticated users to update allocation_products"
  ON allocation_products FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Allow authenticated users to delete allocation_products"
  ON allocation_products FOR DELETE
  TO authenticated
  USING (true);