/*
  # Create tier overrides table

  1. New Tables
    - `tier_overrides`
      - `id` (uuid, primary key)
      - `tier_id` (uuid, references allocation_tiers)
      - `requirements` (jsonb)
      - `discounts` (jsonb)
      - `shipping` (jsonb)
      - `has_product_overrides` (boolean)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `tier_overrides` table
    - Add policies for authenticated users
*/

-- Create tier overrides table
CREATE TABLE IF NOT EXISTS tier_overrides (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tier_id uuid REFERENCES allocation_tiers(id) ON DELETE CASCADE,
  requirements jsonb,
  discounts jsonb,
  shipping jsonb,
  has_product_overrides boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT tier_overrides_tier_id_key UNIQUE (tier_id)
);

-- Add indexes for better performance
CREATE INDEX IF NOT EXISTS idx_tier_overrides_tier_id ON tier_overrides(tier_id);

-- Enable RLS
ALTER TABLE tier_overrides ENABLE ROW LEVEL SECURITY;

-- Create policies for authenticated users
CREATE POLICY "Enable read access for authenticated users"
  ON tier_overrides FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Enable insert access for authenticated users"
  ON tier_overrides FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Enable update access for authenticated users"
  ON tier_overrides FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Enable delete access for authenticated users"
  ON tier_overrides FOR DELETE
  TO authenticated
  USING (true);

-- Add trigger for updated_at
CREATE OR REPLACE FUNCTION update_tier_overrides_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_tier_overrides_updated_at
  BEFORE UPDATE ON tier_overrides
  FOR EACH ROW
  EXECUTE FUNCTION update_tier_overrides_updated_at();

-- Add helpful comments
COMMENT ON TABLE tier_overrides IS 'Stores tier-specific overrides for allocation settings';
COMMENT ON COLUMN tier_overrides.requirements IS 'JSON object containing purchase requirement overrides';
COMMENT ON COLUMN tier_overrides.discounts IS 'JSON object containing discount overrides';
COMMENT ON COLUMN tier_overrides.shipping IS 'JSON object containing shipping overrides';
COMMENT ON COLUMN tier_overrides.has_product_overrides IS 'Flag indicating if tier has product-specific overrides';